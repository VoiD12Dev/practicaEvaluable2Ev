package Practica;

import java.util.ArrayList;
public final class Alga extends Esser{

    //Atributos de clase
    private static int totalAlgues = 0;

    //Atributos de instancia
    private Aliment aliment;
    private boolean reproduccio;

    //Constructor con la clase super, la reproduccion la pongo en false puesto que al principio el ser no se puede reproducir
    public Alga(){
        super("ALGA", pesAlga);
        this.aliment = Aliment.NUTRIENT;
        this.reproduccio = false;
        totalAlgues++;
    }


    public static int dirPoblacio() {
        return totalAlgues;
    }

    //Metodos con @Overrride, polimorfismo
    @Override
    public void reduirPoblacio() {
        totalAlgues--;
        super.reduirPoblacio();
    }

    @Override
    public String mostrarEstat() {
        return "# " + dirNom() + " => PES: " + dirPes();
    }

    @Override
    public String mostrarDetall() {
        if(dirPes() > ((pesAlga * 2) * pesReproduccio)){
            reproduccio = true;
        }
        return "# " + dirNom() + " => PES " + dirPes() + " - ALIMENTACIÓ: " + aliment + " - REPRODUCCIÓ: " + (reproduccio ? "SI" : "NO");
    }

    //Metodo menjar, la algas solo comen nutrientes
    @Override
    public void menjar(ArrayList<Esser> esser) {
        canviaPes(pesNutrients);
        System.out.println("ALIMENTACIÓ **** " + dirNom() + ": m'he menjat un nutrient " + ". Ara pese " + dirPes());
    }

    //Metodo reproduir con excepciones, las algas se dividen varias veces unas vez se cumple al condicion
    @Override
    public void reproduir(ArrayList<Esser> esser) {
        try{
            if(dirPes() > ((pesAlga * 2) * pesReproduccio)){ //Condicion para iniciar la reproduccion
                reproduccio =true;
                do{
                    Alga alga = new Alga();
                    esser.add(alga);
                    canviaPes(-pesAlga);
                    System.out.println("REPRODUCCIÓ **** " + dirNom() + " m'he reproduït i he creat a " + alga.dirNom() + ". Ara pese " + dirPes());
                }
                while(dirPes() >= (pesAlga * pesReproduccio));
            }
            else{
                reproduccio = false;
                throw new IllegalArgumentException("REPRODUCCIÓ **** " + dirNom() + " amb un pes de " + dirPes() + " no em puc reproduir");
            }
        }
        catch (IllegalArgumentException d){
            System.out.println(d.getMessage());
        }
    }

    //Metodo reproduir sin excepciones
    /*@Override
    public void reproduir(ArrayList<Esser> esser) {
        if(dirPes() > ((pesAlga * 2) * pesReproduccio)){ //Condicion para iniciar la reproduccion
            reproduccio =true;
            do{
                Alga alga = new Alga();
                esser.add(alga);
                canviaPes(-pesAlga);
                System.out.println("REPRODUCCIÓ **** " + dirNom() + " m'he reproduït i he creat a " + alga.dirNom() + ". Ara pese " + dirPes());
            }
            while(dirPes() >= (pesAlga * pesReproduccio));
        }
        else{
            reproduccio = false;
            System.out.println("REPRODUCCIÓ **** " + dirNom() + " amb un pes de " + dirPes() + " no em puc reproduir");
        }
    }*/
}
