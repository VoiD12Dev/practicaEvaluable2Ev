package Practica;

import java.util.ArrayList;
public interface Poblacio {

    //Atributos de interface
    int pesReproduccio = 3;
    int numMaxim=20;

    //Metodos a implementar
    void reduirPoblacio();
    void reproduir(ArrayList <Esser> esser);
}
