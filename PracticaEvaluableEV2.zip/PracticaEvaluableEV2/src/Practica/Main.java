package Practica;
import java.util.Scanner;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<Esser> esser = new ArrayList<Esser>();
        Scanner ent = new Scanner(System.in);

        //Crea un array para almacenar los valores introducidos para cada ser
        int[] hue = new int[3];
        hue[0] = llegirNumero("ameba", Esser.numMaxim, 0, true);
        hue[1] = llegirNumero("bacteri", Esser.numMaxim, 0, true);
        hue[2] = llegirNumero("alga", Esser.numMaxim, 0, true);

        crearEssers(hue, esser);
        processaMenu(esser);
    }

    //Metodo para verificar que los valores introducidos por consola sean validos
    public static int llegirNumero(String tipo, int numeroMax, int numeroMin, boolean decir) {
        Scanner ent = new Scanner(System.in);
        boolean opcioValida1 = false;
        int a = 0;

        do {
            try {
                System.out.println((decir ? "- Introdueix el nombre de " + tipo + " (de " + numeroMin + " a " + numeroMax + "): " : ""));

                if (ent.hasNextInt()) {
                    a = ent.nextInt();
                    if ((a >= numeroMin) && (a <= numeroMax)) {
                        opcioValida1 = true;
                    } else {
                        throw new IllegalArgumentException("ERROR: Ha d'introduir un número entre " + numeroMin + " i " + numeroMax + ".");
                    }
                } else {
                    throw new IllegalArgumentException("ERROR: No s’ha introduït un valor numèric.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                ent.nextLine();

            }
        }
        while (!opcioValida1);
        return a;
    }

    /*Metodo para colocar aleatoriamente los seres en el ArrayList. Hace paso por referencia del array de seres vivos
    introducidos y el ArrayList de Essers.*/
    public static void crearEssers(int[] hue, ArrayList<Esser> esser) {
        int c, eleccion;
        int totalEssers = 0, totalColocados = 0;

        for (c = 0; c < hue.length; c++) {
            totalEssers += hue[c];
        }

        int totalAmebas = 0, totalBacteris = 0, totalAlgas = 0;

        do {
            eleccion = Esser.generaAleatori(1, 3);

            switch (eleccion) {

                case 1: //Introduce Ameba
                    if (hue[0] > totalAmebas) {
                        esser.add(new Ameba());
                        totalAmebas++;
                        totalColocados++;
                    }
                    break;

                case 2: //Introduce Bacteri
                    if (hue[1] > totalBacteris) {
                        esser.add(new Bacteri());
                        totalBacteris++;
                        totalColocados++;
                    }
                    break;

                case 3: //Introduce Alga
                    if (hue[2] > totalAlgas) {
                        esser.add(new Alga());
                        totalAlgas++;
                        totalColocados++;
                    }
                    break;
            }
        }
        while (totalColocados != totalEssers);
    }

    //Metodo para el menu principal del programa.
    public static void processaMenu(ArrayList<Esser> esser) {
        Scanner ent = new Scanner(System.in);
        int opcio;
        boolean salida = false;

        do {
            System.out.println("«OPCIONS==> 1.-Una Interacció, 2.-Deu Interaccions, 3.-Llistat, 4-Detall 0.-Eixir: «");
            opcio = llegirNumero("opcio", 4, 0, false);

            switch (opcio) {

                case 1: //Produce una interaccion
                    produeixInteraccio(esser);
                    break;

                case 2: //Produce 10 interacciones por un "for"
                    for (int i = 0; i < 10; i++) {
                        produeixInteraccio(esser);
                    }
                    break;

                case 3: //Muestra la lista completa de seres.
                    mostrarLListaEssers(esser);
                    break;

                case 4: //Busca y muestra la lista completa del ser buscado
                    mostraEsser(esser);
                    break;

                case 0: //Salida del programa
                    salida = true;
                    mostrarLListaEssers(esser);
                    System.out.println("Gracias! Hasta pronto!");
                    break;
            }
        }
        while (!salida);
        ent.close();
    }

    //Muestra la lista completa de seres con su peso. Tambien el total de seres y de cada uno de ellos
    public static void mostrarLListaEssers(ArrayList<Esser> esser) {

        for(int i=0; i<esser.size(); i++){
            System.out.println(esser.get(i).mostrarEstat());
        }
        System.out.println("");

        System.out.println("POBLACIÓ: TOTAL ESSERS=>" + Esser.dirPoblacio() + ", AMEBES=>" + Ameba.dirPoblacio() + ", BACTERIES=>" +
                Bacteri.dirPoblacio() + ", ALGUES=>" + Alga.dirPoblacio());
    }

    //Busca un tipo de ser y muestra cuantos hay y su situacion con detalle
    public static void mostraEsser(ArrayList<Esser> esser) {
        Scanner ent = new Scanner(System.in);
        String opcion;
        System.out.println("Quin esser vols buscar? (Ameba, Bacteri o Alga)");
        opcion = ent.nextLine();

        switch (opcion) {
            case "Ameba":
                for (int i = 0; i < esser.size(); i++) {
                    if (esser.get(i) instanceof Ameba) {
                        System.out.println(esser.get(i).mostrarDetall());
                    }
                }
                break;
            case "Bacteri":
                for (int i = 0; i < esser.size(); i++) {
                    if (esser.get(i) instanceof Bacteri) {
                        System.out.println(esser.get(i).mostrarDetall());
                    }
                }
                break;
            case "Alga":
                for (int i = 0; i < esser.size(); i++) {
                    if (esser.get(i) instanceof Alga) {
                        System.out.println(esser.get(i).mostrarDetall());
                    }
                }
                break;
            default:
                System.out.println("«ERROR: el microorganisme»" + opcion + "« no apareix en la llista.»");
                break;
        }
    }

    /*Metodo para producir interacciones. ¡¡OJO!! Como no se especifica en el PDF de la practica, se entiende que el
    * Alga come y se reproduce si puede en la misma interaccion. Siendo la interaccion mas extensa si se reproduce.*/
    public static void produeixInteraccio(ArrayList<Esser> esser){ //revisar los if por si se puede convertir a switch
        int esserTriat = Esser.generaAleatori(0,esser.size());
        int opcio;
        Esser triat = esser.get(esserTriat);

        if (triat instanceof Ameba) {
            opcio = Esser.generaAleatori(0,2);
            switch (opcio) {
                case 0:
                    triat.menjar(esser);
                    break;
                case 1:
                    triat.reproduir(esser);
                    break;
            }
        }

        else if (triat instanceof Bacteri) {
            opcio = Esser.generaAleatori(0,2);
            switch (opcio) {
                case 0:
                    triat.menjar(esser);
                    break;
                case 1:
                    triat.reproduir(esser);
                    break;
            }
        }

        //El Alga come y se intenta reproducir en la misma interaccion
        else if(triat instanceof Alga){
            triat.menjar(esser);
            triat.reproduir(esser);
        }
    }
}