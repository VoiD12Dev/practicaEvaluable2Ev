package Practica;

import java.util.ArrayList;

public final class Bacteri extends Esser {

    //Atributos de clase
    private static int totalBacteris = 0;

    //Atributos de instancia
    private Aliment aliment;
    private boolean reproduccio;

    //Constructor con la clase super, la reproduccion la pongo en false puesto que al principio el ser no se puede reproducir
    public Bacteri(){
        super("BACTERI", pesBacteri);
        this.aliment = Aliment.ALGA;
        this.reproduccio = false;
        totalBacteris++;
    }


    public static int dirPoblacio() {
        return totalBacteris;
    }

    //Metodos @Override, polimorfismo
    @Override
    public String mostrarEstat() {
        return "/ " + dirNom() + " => PES: " + dirPes();
    }

    @Override
    public String mostrarDetall() {
        if(dirPes() >= (pesReproduccio * (pesBacteri*2))){
            reproduccio = true;
        }
        return "/ " + dirNom() + " => PES " + dirPes() + " - ALIMENTACIÓ: " + aliment + " - REPRODUCCIÓ: " + (reproduccio ? "SI" : "NO");
    }

    //Metodo menjar con excepciones, si quedan algas, elige una aleatoria y se la come
    @Override
    public void menjar(ArrayList<Esser> esser) {
        boolean puedeComer = false, salir = false;
        //int posicion = esser.indexOf(this);
        int aleatorio;
        Esser devorado;
        for (int i = 0 ; i < esser.size() ; i++) {
            Esser a = esser.get(i);
            if (a instanceof Alga) {
                puedeComer = true;
            }
        }
        try{
            if(puedeComer) {
                do {
                    aleatorio = generaAleatori(0,esser.size());
                    if (esser.get(aleatorio) instanceof Alga){
                        devorado = esser.get(aleatorio);
                        canviaPes(devorado.dirPes());
                        System.out.println("ALIMENTACIÓ **** " + dirNom() + ": m'he menjat a " + devorado.dirNom() + ". Ara pese " + dirPes());
                        devorado.reduirPoblacio();
                        esser.remove(devorado);
                        salir = true;
                    }
                }
                while (!salir);
            }
            else {
                throw new IllegalArgumentException("El Bacteri no te alges per menjar");
            }
        }
        catch (IllegalArgumentException c){
            System.out.println(c.getMessage());
        }
    }

    //Metodo menjar sin excepciones
    /*@Override
    public void menjar(ArrayList<Esser> esser) {
        boolean puedeComer = false, salir = false;
        //int posicion = esser.indexOf(this);
        int aleatorio;
        Esser devorado;
        for (int i = 0 ; i < esser.size() ; i++) {
            Esser a = esser.get(i);
            if (a instanceof Alga) {
                puedeComer = true;
            }
        }
        if(puedeComer) {
            do {
                aleatorio = generaAleatori(0,esser.size());
                if (esser.get(aleatorio) instanceof Alga){
                    devorado = esser.get(aleatorio);
                    canviaPes(devorado.dirPes());
                    System.out.println("ALIMENTACIÓ **** " + dirNom() + ": m'he menjat a " + devorado.dirNom() + ". Ara pese " + dirPes());
                    devorado.reduirPoblacio();
                    esser.remove(devorado);
                    salir = true;
                }
            }
            while (!salir);
        }
        else {
            System.out.println("El Bacteri no te alges per menjar");
        }
    }*/

    @Override
    public void reduirPoblacio() {
        totalBacteris--;
        super.reduirPoblacio();
    }

    //Metodo reproducir con excepciones, si se cumple la condicion la bacteria se divide en peso
    @Override
    public void reproduir(ArrayList<Esser> esser) {
        try{
            if (dirPes() >= (pesReproduccio * (pesBacteri*2))){
                reproduccio = true;
                Bacteri bacteri = new Bacteri();
                esser.add(bacteri);
                int pesDivision = (dirPes()/2);
                canviaPes(-pesDivision);
                bacteri.canviaPes(pesDivision - pesBacteri);
                System.out.println("REPRODUCCIÓ **** " + dirNom() + " m'he reproduït i he creat a " + bacteri.dirNom() + ". Ara pese " + dirPes());
            }
            else{
                reproduccio = false;
                throw new IllegalArgumentException("REPRODUCCIÓ **** " + dirNom() + " amb un pes de " + dirPes() + " no em puc reproduir");
            }
        }
        catch (IllegalArgumentException b){
            System.out.println(b.getMessage());
        }
    }

    //MEtodo reproducir sin excepciones
    /*@Override
    public void reproduir(ArrayList<Esser> esser) {
        if (dirPes() >= (pesReproduccio * (pesBacteri*2))){
            reproduccio = true;
            Bacteri bacteri = new Bacteri();
            esser.add(bacteri);
            int pesDivision = (dirPes()/2);
            canviaPes(-pesDivision);
            bacteri.canviaPes(pesDivision - pesBacteri);
            System.out.println("REPRODUCCIÓ **** " + dirNom() + " m'he reproduït i he creat a " + bacteri.dirNom() + ". Ara pese " + dirPes());
        }
        else{
            reproduccio = false;
            System.out.println("REPRODUCCIÓ **** " + dirNom() + " amb un pes de " + dirPes() + " no em puc reproduir");
        }
    }*/
}
