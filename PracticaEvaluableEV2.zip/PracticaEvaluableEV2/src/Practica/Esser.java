package Practica;

import java.util.Random;

public abstract class Esser implements Alimentacio, Poblacio {

    //Atributos de clase
    private static int totalEssers = 0;
    private static int consecutiu = 1;

    //Atributos de instancia
    private final String nom;
    private int pes;

    //Constructor
    protected Esser(String nom, int pesInicial) {
        this.nom = nom + (consecutiu++);
        this.pes = pesInicial;
        totalEssers++;
    }

    public String dirNom() {
        return nom;
    }

    public int dirPes() {
        return pes;
    }

    public void canviaPes(int increment) {
        pes += increment;
    }

    //Metodo para generar un numero aleatorio en el arango de enteros que se le pasen
    public static int generaAleatori(int inicial, int quantitat) {
        int a;
        Random e = new Random();
        a = e.nextInt(quantitat) + inicial;
        return a;
    }

    public static int dirPoblacio(){
        return totalEssers;
    }

    //Metodos abstract a implementar en las subclases
    public abstract String mostrarEstat();

    public abstract String mostrarDetall();

    public void reduirPoblacio(){
        totalEssers--;
    }
}
