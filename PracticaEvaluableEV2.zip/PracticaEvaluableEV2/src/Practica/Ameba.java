package Practica;

import java.util.ArrayList;

public final class Ameba extends Esser {

    //Atributos de clase
    private static int totalAmebes = 0;

    //Atributos de instancia
    private Aliment aliment;
    private boolean reproduccio;

    //Constructor con la clase super, la reproduccion la pongo en false puesto que al principio el ser no se puede reproducir
    public Ameba (){
        super("AMEBA", pesAmeba);
        this.aliment = Aliment.TOT;
        this.reproduccio = false;
        totalAmebes++;
    }


    public static int dirPoblacio() {
        return totalAmebes;
    }

    //Metodos @Override, polimorfismo
    @Override
    public String mostrarEstat(){
        return  "@ " + dirNom() + " => PES:" + dirPes();
    }

    @Override
    public String mostrarDetall(){
        if(dirPes() >= (pesAmeba * pesReproduccio)){
            reproduccio = true;
        }
        return  "@ " + dirNom() + " => PES " + dirPes() + " - ALIMENTACIÓ: " + aliment + " - REPRODUCCIÓ: " +(reproduccio ? "SI" : "NO");

    }

    /*Metodo menjar, si queda solo una ameba, no puede comer, avisara de que no se pueden producir
    * mas interacciones en este metodo. Aunque sigue pudiendose reproducir*/
    @Override
    public void menjar(ArrayList <Esser> esser) {
        int posicion = esser.indexOf(this);
        int aleatorio;

        if (esser.size() == 1) {
            System.out.println("Sols queda una Ameba, no es poden produir mes interaccions!");
        } else {
            do {
                aleatorio = generaAleatori(0, esser.size());
            }

            while (aleatorio == posicion);

            Esser devorada = esser.get(aleatorio);
            canviaPes(devorada.dirPes());
            System.out.println("ALIMENTACIÓ **** " + dirNom() + ": m'he menjat a " + devorada.dirNom() + ". Ara pese " + dirPes());
            devorada.reduirPoblacio();
            esser.remove(devorada);
        }
    }

    @Override
    public void reduirPoblacio() {
        totalAmebes--;
        super.reduirPoblacio();
    }

    //Metodo reproduir con excepciones, si se cumple la condicion, produce una nueva ameba con un peso declarado constante
    @Override
    public void reproduir(ArrayList <Esser> esser) {
        try {
            if (dirPes() >= (pesAmeba * pesReproduccio)) {
                reproduccio = true;
                Ameba ameba = new Ameba();
                esser.add(ameba);
                canviaPes(-ameba.dirPes());
                System.out.println("REPRODUCCIÓ **** " + dirNom() + " m'he reproduït i he creat a " + ameba.dirNom() + ". Ara pese " + dirPes());
            } else {
                reproduccio = false;
                throw new IllegalArgumentException("REPRODUCCIÓ **** " + dirNom() + " amb un pes de " + dirPes() + " no em puc reproduir");

            }
        }
        catch (IllegalArgumentException a){
            System.out.println(a.getMessage());
        }
    }

    //Metodo reproduir sin excepciones
    /*@Override
    public void reproduir(ArrayList <Esser> esser) {  //Ameba
        if (dirPes() >= (pesAmeba * pesReproduccio)){
            reproduccio = true;
            Ameba ameba = new Ameba();
            esser.add(ameba);
            canviaPes(-ameba.dirPes());
            System.out.println("REPRODUCCIÓ **** " + dirNom() + " m'he reproduït i he creat a " + ameba.dirNom() + ". Ara pese " + dirPes());
        }
        else{
            reproduccio = false;
            System.out.println("REPRODUCCIÓ **** " + dirNom() + " amb un pes de " + dirPes() + " no em puc reproduir");
        }
    }*/
}
