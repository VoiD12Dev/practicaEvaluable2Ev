package Practica;

public enum Aliment {
    TOT,AMEBA,BACTERI,ALGA,NUTRIENT
}
