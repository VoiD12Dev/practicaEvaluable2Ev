package Practica;

import java.util.ArrayList;

public interface Alimentacio {

    //Atributos de interface, constantes de pesos
    int pesAmeba = 20;
    int pesBacteri= 10;
    int pesAlga = 3;
    int pesNutrients = 5;

    //Metodos a implementar
    void menjar (ArrayList <Esser> essers);
}
